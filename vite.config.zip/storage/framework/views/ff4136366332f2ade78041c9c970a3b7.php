<!-- resources/views/kasir/detail.blade.php -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Transaksi</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>

        html, body { height: 100%; margin: 0; }

    </style>
</head>
<body>
    <div 
        class="min-h-screen bg-cover bg-center flex items-center justify-center px-4"
        style="background-image: url('<?php echo e(asset('images/geolig.jpg')); ?>');"
    >
        <div class="max-w-3xl bg-white bg-opacity-90 shadow-xl rounded-xl p-6 w-full">
            <h2 class="text-2xl font-bold mb-4 text-gray-800">🧾 Detail Transaksi</h2>

            <div class="mb-6 space-y-2 text-gray-700">
                <p><strong>No Meja:</strong> <?php echo e($transaksi->order->meja->nomor ?? '-'); ?></p>
            </div>

            <div class="overflow-x-auto">
                <table class="w-full text-left border border-gray-300 rounded">
                    <thead class="bg-yellow-100 text-gray-800">
                        <tr>
                            <th class="px-4 py-2 border">Menu</th>
                            <th class="px-4 py-2 border">Qty</th>
                            <th class="px-4 py-2 border">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody class="text-gray-700">
                        <?php $total=0; ?>
                        <?php $__currentLoopData = $transaksi->order->orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $subtotal = $item->quantity * $item->price; $total += $subtotal; ?>
                            <tr>
                                <td class="px-4 py-2 border"><?php echo e($item->menu->nama); ?></td>
                                <td class="px-4 py-2 border"><?php echo e($item->quantity); ?></td>
                                <td class="px-4 py-2 border">Rp <?php echo e(number_format($subtotal,0,',','.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td colspan="2" class="px-4 py-2 border text-right">Subtotal</td>
                            <td class="px-4 py-2 border">Rp <?php echo e(number_format($subTotal,0,',','.')); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="px-4 py-2 border text-right">Service Charge (5%)</td>
                            <td class="px-4 py-2 border">Rp <?php echo e(number_format($serviceCharge,0,',','.')); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="px-4 py-2 border text-right">PB1 (10%)</td>
                            <td class="px-4 py-2 border">Rp <?php echo e(number_format($pb1,0,',','.')); ?></td>
                        </tr>
                        <tr>
                            <td colspan="2" class="px-4 py-2 border text-right">Pembulatan</td>
                            <td class="px-4 py-2 border">Rp -<?php echo e(number_format($roundingAmount,0,',','.')); ?></td>
                        </tr>
                        <tr class="bg-yellow-100 font-semibold">
                            <td colspan="2" class="px-4 py-2 border text-right">Total Akhir</td>
                            <td class="px-4 py-2 border">Rp <?php echo e(number_format($roundedTotal,0,',','.')); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <form action="<?php echo e(route('kasir.bayar', $transaksi->id)); ?>" method="POST" class="mt-6 space-y-3">
                <?php echo csrf_field(); ?>
                <input type="number" name="jumlah_dibayar" placeholder="Masukkan jumlah dibayar" required
                       class="w-full border border-gray-300 rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-yellow-400">

                <button type="submit" class="w-full bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 rounded">
                    💵 Bayar
                </button>
            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\sistem-pemesanan-cafe-dengan-qr-code\resources\views\kasir\detail.blade.php ENDPATH**/ ?>